"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.models = void 0;
const models = {
    storageModel: require('./sql/storage'),
};
exports.models = models;
