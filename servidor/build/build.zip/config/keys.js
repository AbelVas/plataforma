"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    database: {
        host: '204.93.224.100',
        user: 'flrsjejd_brincoteca',
        password: 'macromish40322454',
        database: 'flrsjejd_plataformaplanbasico_brincoteca'
    }
};
/*
CONEXION BRINCOTECA PRODUCCION

        host: '204.93.224.100',
        user: 'flrsjejd_brincoteca',
        password: 'macromish40322454',
        database: 'flrsjejd_plataformaplanbasico_brincoteca'

CONEXION VERAPAZ PRODUCCION

        host: '75.102.58.70',
        user: 'nthdovqx_academicoverapaz',
        password: 'macromish40322454',
        database: 'nthdovqx_plataforma_academicoverapaz'

CONEXION BRINCOTECA TEST

        host:'204.93.224.100',
        user:'flrsjejd_plataforma',
        password:'macromish40322454',
        database:'flrsjejd_plataformaplanbasico_test'
*/ 
